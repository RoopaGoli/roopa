package com.hackathon.service.main.controller;

import java.io.IOException;
import java.io.InputStream;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
public class MemberDetailsMockController {

	private ClassPathResource classPathResource;
	private InputStream inputStream;
	private String jsonOutput;
	private ObjectMapper objectMapper = new ObjectMapper();

	@RequestMapping(value = "/member-details/{member-identifier}", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public String memberProfile(
			@PathVariable("member-identifier") final String memberId)
			throws JsonProcessingException, IOException {

		String fileName = "/JsonOutputFiles/MemberProfile/" + memberId + ".json";
		classPathResource = new ClassPathResource(fileName);
		inputStream = classPathResource.getInputStream();

		JsonNode rootNode = objectMapper.readTree(inputStream);
		jsonOutput = objectMapper.writerWithDefaultPrettyPrinter()
				.writeValueAsString(rootNode);
		return jsonOutput;
	}
	
	
	
	@RequestMapping(value = "/member-details/{member-identifier}/avios", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public String aviosBalance(
			@PathVariable("member-identifier") final String memberId)
			throws JsonProcessingException, IOException {

		String fileName = "/JsonOutputFiles/AviosBalance/" + memberId + ".json";
		classPathResource = new ClassPathResource(fileName);
		inputStream = classPathResource.getInputStream();

		JsonNode rootNode = objectMapper.readTree(inputStream);
		jsonOutput = objectMapper.writerWithDefaultPrettyPrinter()
				.writeValueAsString(rootNode);
		return jsonOutput;
	}
	
	@RequestMapping(value = "/member-details/{member-identifier}/favourite-destinations", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public String favDestinations(
			@PathVariable("member-identifier") final String memberId)
			throws JsonProcessingException, IOException {

		String fileName = "/JsonOutputFiles/FavouriteDestinations/" + memberId + ".json";
		classPathResource = new ClassPathResource(fileName);
		inputStream = classPathResource.getInputStream();

		JsonNode rootNode = objectMapper.readTree(inputStream);
		jsonOutput = objectMapper.writerWithDefaultPrettyPrinter()
				.writeValueAsString(rootNode);
		return jsonOutput;
	}
	
	
	
	@RequestMapping(value = "/member-details/{member-identifier}/search-data-history", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public String searchDataHistory(
			@PathVariable("member-identifier") final String memberId)
			throws JsonProcessingException, IOException {

		String fileName = "/JsonOutputFiles/SearchDataHistory/" + memberId + ".json";
		classPathResource = new ClassPathResource(fileName);
		inputStream = classPathResource.getInputStream();

		JsonNode rootNode = objectMapper.readTree(inputStream);
		jsonOutput = objectMapper.writerWithDefaultPrettyPrinter()
				.writeValueAsString(rootNode);
		return jsonOutput;
	}
	
	@RequestMapping(value = "/member-details/{member-identifier}/booked-history", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public String bookedHistory(
			@PathVariable("member-identifier") final String memberId)
			throws JsonProcessingException, IOException {

		String fileName = "/JsonOutputFiles/BookedHistory/" + memberId + ".json";
		classPathResource = new ClassPathResource(fileName);
		inputStream = classPathResource.getInputStream();

		JsonNode rootNode = objectMapper.readTree(inputStream);
		jsonOutput = objectMapper.writerWithDefaultPrettyPrinter()
				.writeValueAsString(rootNode);
		return jsonOutput;
	}
}

